// Navbar tab opener
const tabs = ["index.html","index(product).html","index(news).html","index(Q&A).html","index(about).html","index(Log-in).html"] ;
function OpenAnotherpage(TabParam) {
    window.open(tabs[TabParam] , "_self");
}

// tooltip
function outFunc() {
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "کلیک برای کپی";
}

//toast + NumberUp
const toastTrigger = document.getElementById('liveToastBtn')
const toastLiveExample = document.getElementById('liveToast')
var likes = 0 ;
var dislikes = 0 ;
var IconCeck = '<i class="bi bi-check-lg"></i>'
var IconX = '<i class="bi bi-x"></i>'

function showtoast(btn){
  const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
  toastBootstrap.show()

  if(btn == 1){
    likes++;
    $(".CHECK").text(likes);
    $(".CHECK").prepend(IconCeck);
  }
  else if(btn == 0) {
    dislikes++;
    $(".X").text(dislikes);
    $(".X").prepend(IconX);
  }

}

// log in and sign in page opener
// zero '0' stand for sign up and one '1' stand for log in
function OpenLogPage(PageCode){
  if(PageCode == 1){
    $("#login").removeClass("d-none");
    $("#signup").addClass("d-none");
  }
  else if(PageCode == 0){
    $("#login").addClass("d-none");
    $("#signup").removeClass("d-none");
  }
}

// sign in validation


//unsee this
function what() {
  $("#what-toggle").addClass("d-none")
}